# repository

[![Maintainability](https://api.codeclimate.com/v1/badges/859165fe70e366de7497/maintainability)](https://codeclimate.com/github/epanin/brain_games/maintainability)
